//EXCLAIMER:
/*GUESS THE ANSWERS IF YOU CAN'T JUST FIND THE SOLUTIONS FOR THE
SAME EXERCISE
USE CONSOLE.LOG IF YOU ARE USING VSCODE TEXT EDITOR OR
COPY AND PASTE IT DIRECTLY TO THE WEB BROWSER CONSOLE

*/

//DO THE FOLLOWING EVALUATION
5+6 // 11 console.log(5 + 6)
6 + '7' // 67 console.log(6 + '7')
8  - '7'// 1 console.log(8 - '7')
10 % 5 // 0
11 % 5 // 1
//false is 0 and true is 1
true + false //  1
false + true // 1
true + true // 2
false + false //0
"I"+"Like"+"YOU!" // ILIKEYOU
"It\'s my turn" //It's my turn