//JAVASCRIPT TYPES

//1) NUMBER
console.log(3+7);
console.log(10-9);
console.log(10*3);
console.log(20/5);
console.log((6-2)*(4-2));

//2)STRING
console.log('Rick');
console.log("Sekuloski");
console.log('Rick' +' '+ 'Sekuloski');
console.log('Rick\'s car');

console.log(33+' years');

console.log(33 - '10');

//BOOLEAN TRUE OR FALSE
console.log(5>4);
console.log(5<5);
console.log(5>=5);
console.log(5<=5);

