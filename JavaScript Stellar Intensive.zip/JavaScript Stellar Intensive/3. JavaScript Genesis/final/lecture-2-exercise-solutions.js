//EXCLAIMER:
/*GUESS THE ANSWERS IF YOU CAN'T JUST FIND THE SOLUTIONS FOR THE
SAME EXERCISE
USE CONSOLE.LOG IF YOU ARE USING VSCODE TEXT EDITOR OR
COPY AND PASTE IT DIRECTLY TO THE WEB BROWSER CONSOLE
*/

//DO THE FOLLOWING COMPARISON
6 > 5 // true
5 >= 6 // false
5 <= 6 // true
true === false //false
false === true //false
true != true //false
false === false // true
'C' > 'D' //false
'C' > 'A' //true
