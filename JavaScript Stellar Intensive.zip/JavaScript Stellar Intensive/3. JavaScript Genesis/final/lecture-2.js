
//JAVASCRIPT COMPARISON OPERATORS
/*

multi line comment

*/
console.log('JAVASCRIPT COMPARISON OPERATORS');


console.log(5 > 5);
console.log(5 < 6);
console.log(5 >= 5);
console.log(5 <= 4);

console.log(5 === 5);

console.log(6 !== 5);//not equal type and not equal value
console.log(6 !== 'something');//not equal type and not equal value
