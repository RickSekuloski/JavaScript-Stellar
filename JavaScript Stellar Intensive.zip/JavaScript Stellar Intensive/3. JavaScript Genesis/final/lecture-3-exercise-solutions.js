//EXCLAIMER:
/*GUESS THE ANSWERS IF YOU CAN'T JUST FIND THE SOLUTIONS FOR THE
SAME EXERCISE
USE CONSOLE.LOG IF YOU ARE USING VSCODE TEXT EDITOR OR
COPY AND PASTE IT DIRECTLY TO THE WEB BROWSER CONSOLE

*/

//DO THE FOLLOWING
//1) create a variable called first name using camel case notation
//2) assign a value to that variable, preferably your name
//3) var c? What is c equal to, console it 
//4) create two variable a and z
//5) give variable a value 5 and variable z value 3
//6) what a + z will give us?
//7) Now give variable a = 1 and do a + z again
//8) Make calculator that prompts the user for two numbers
//9) store the values of that two numbers in any variables you want
//10) Display back with alert their multiplication

//1, 2
var fistName;
firstName = 'Rick';
//3
var c;
console.log(c);//undefined
//4 , 5
var a,z;
a = 5;
z = 3;
//6
console.log(a + z); //8 
//7
a = 1;
console.log(a+z); // 4

//8,9,10
var first = prompt('Enter The First Number:');
var second = prompt('Enter The Second Number:');
alert('The result is: '+ (first*second));
