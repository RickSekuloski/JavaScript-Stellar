//JAVASCRIPT VARIABLES

//console.log(5+9);

var myName = 'Rick';
console.log(myName);
var sum = 5+9;
console.log(sum);
var result = sum - 5;
console.log(result);
console.log('This is the result from the variable: '+result );

//var names can start with letter, underscore or $
//variables are case-sensitive
var age = prompt('How Old Are You?');
var year = prompt('What Is The Current Year?');
alert('I was born in: '+(year - age));

//UNDEFINED JS TYPE
var lastName;
lastName = 'Sekuloski';
console.log(lastName);
