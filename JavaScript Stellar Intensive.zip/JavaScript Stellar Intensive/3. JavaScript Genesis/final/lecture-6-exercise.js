//ARRAY EXERCISES, USE CONSOLE LOG TO PRINT THE RESULT
//USE THE FOLLOWING ARRAY
var cars = ["Saab", "Volvo", "BMW","Audi","Tesla","Ford","Lexus","HSV","Toyota","Chevrolet"];

//0) Sort Array
//1) Remove the First Item from the array and store it in a variable
//2) Remove the Last Item From the array and store it in a variable
//3) Remove Ford from the array and store it in a variable
//find out the method that do this online and this returns an array back like this ["Ford"]
//4)  Add Audi, Volvo and the returned Ford array in new array called cars1
//5) Access Ford from cars1
//6) Save now the ford item into a variable
//7) Add Audi, Volvo and the Ford now to the original cars array
//8) Sort the original cars array in reverse order
