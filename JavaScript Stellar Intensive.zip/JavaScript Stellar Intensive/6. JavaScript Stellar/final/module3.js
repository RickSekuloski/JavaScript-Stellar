//DYNAMIC IMPORT
const multiply = (num1, num2)=>{
    return num1 * num2;
}
export {multiply};